"""Export lab.json for the construction lab page."""
import json, sys
import numpy as np
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
sys.path.insert(0, ".")
from relax import Glyph

f = TTFont("../in/f2f3efd1-Koradin.otf"); gs = f.getGlyphSet()
SK = json.load(open("skeleton2.json")); M = json.load(open("masters2.json"))
G = json.load(open("../p1/pairs.json"))["glyphs"]
KEYS = ["thin", "regular", "w74", "w86", "black"]
ms = M["masters"]

def viol_points(Gl, X, w, k=6):
    if Gl.n < 2: return []
    D = np.linalg.norm(X[:, None] - X[None], axis=2)
    r = Gl.radii(w); req = r[:, None] + r[None] + Gl.gapmat(w)
    bad = (~Gl.same_ink) & (D < req - 1.0); np.fill_diagonal(bad, False)
    I, J = np.nonzero(np.triu(bad))
    if not len(I): return []
    sev = (req - D)[I, J]; order = np.argsort(-sev)
    pts = []
    for o in order:
        m = (X[I[o]] + X[J[o]]) / 2
        if all(np.hypot(m[0] - p[0], m[1] - p[1]) > 60 for p in pts):
            pts.append([round(float(m[0])), round(float(m[1])), round(float(sev[o]), 1)])
        if len(pts) >= k: break
    return pts

out = []
order = sorted(G.items(), key=lambda x: (x[1][0], ["a", "e", "ɛ", "i", "o", "ɔ", "u"].index(x[1][1])))
for n, (on, v) in order:
    if n not in SK: continue
    g = SK[n]
    sp = SVGPathPen(gs); gs[n].draw(sp)
    Gl = Glyph(g)
    P = {}; V = {}
    for k in KEYS:
        X = np.array(M["pos"][n][k])
        P[k] = [int(round(c)) for xy in X for c in xy]
        V[k] = viol_points(Gl, X, ms[k])
    out.append({"n": n, "s": (on or "") + v, "row": on, "v": v, "comp": g.get("comp", ""), "src": sp.getCommands(), "adv": f["hmtx"][n][0],
                "strokes": [{"i": s["idx"], "c": bool(s["closed"]), "e": s["ends"], "r": s.get("role", "radical"), "g": s.get("segs", [])} for s in g["strokes"]],
                "np": len(g["particles"]), "dots": len(g["dots"]), "P": P, "viol": V, "worst": M["worst"].get(n, 0)})
json.dump({"masters": {k: ms[k] for k in KEYS}, "wmap": {"thin": 100, "regular": 400, "w74": 560, "w86": 720, "black": 900}, "glyphs": out},
          open(sys.argv[1], "w"), separators=(",", ":"), ensure_ascii=False)
print(len(out), "glyphs;", sum(1 for o in out if o["worst"] < 1), "pass the rule at every weight")
