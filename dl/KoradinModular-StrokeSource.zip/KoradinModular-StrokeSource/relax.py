"""Collision-safe weight masters.

Rule: at any stroke width w, two parts of a glyph may only touch if they already
touched in the master (Koradin Dua, w0 = 62). Points close along the stroke itself
(geodesic distance below T(w)) are the same piece of ink and are exempt.

Solver: position-based relaxation of the skeleton particles.
  - separation: non-exempt pairs pushed to at least  r_i + r_j + gap(w)
  - shape: segment lengths and local bends pulled back toward the master shape
  - alignment: strokes resting on the baseline / top line keep their outer edge on the line
Point count never changes, so every master interpolates with every other.
"""
import json, math, sys
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import shortest_path

W0 = 62.0
TOP = 700.0


def gap(w):
    return max(12.0, 0.33 * w)


RATIO = 1.5   # geodesic / straight distance below this = same piece of ink (straight runs, right-angle corners)


class Glyph:
    def __init__(self, g, mark=False):
        self.g = g
        self.mark = mark
        P = np.array(g["particles"], float) if g["particles"] else np.zeros((0, 2))
        self.n_part = len(P)
        dots = g["dots"]
        # dots become particles too (index after stroke particles)
        self.dot_idx = []
        if dots:
            P = np.vstack([P, np.array([[d[0], d[1]] for d in dots])]) if len(P) else np.array([[d[0], d[1]] for d in dots], float)
            self.dot_idx = list(range(self.n_part, self.n_part + len(dots)))
        self.P0 = P
        n = len(P)
        self.n = n
        # graph edges along strokes
        ei, ej, segs, trip = [], [], [], []
        free = np.zeros(n, bool)
        for s in g["strokes"]:
            idx = s["idx"]
            m = len(idx)
            rng = range(m) if s["closed"] else range(m - 1)
            for k in rng:
                a, b = idx[k], idx[(k + 1) % m]
                if a == b: continue
                ei.append(a); ej.append(b); segs.append((a, b))
            for k in range(m if s["closed"] else m - 2):
                a, b, c = idx[k], idx[(k + 1) % m], idx[(k + 2) % m]
                if len({a, b, c}) == 3: trip.append((a, b, c))
            if not s["closed"]:
                if s["ends"][0] == "free": free[idx[0]] = True
                if s["ends"][1] == "free": free[idx[-1]] = True
        self.free = free
        self.seqs = [(s["idx"], s["closed"]) for s in g["strokes"]]
        cm = np.zeros(n, bool)
        for s in g["strokes"]:
            for j, i in enumerate(s["idx"]):
                if s["corner"][j]: cm[i] = True
        self.corner_mask = cm
        self.segs = np.array(segs, int).reshape(-1, 2)
        self.trip = np.array(trip, int).reshape(-1, 3)
        if n:
            L = np.linalg.norm(P[self.segs[:, 0]] - P[self.segs[:, 1]], axis=1) if len(self.segs) else np.zeros(0)
            self.L0 = L
            Gm = coo_matrix((np.concatenate([L, L]), (np.concatenate([self.segs[:, 0], self.segs[:, 1]]),
                                                     np.concatenate([self.segs[:, 1], self.segs[:, 0]]))), shape=(n, n)).tocsr()
            self.geo = shortest_path(Gm, directed=False)
            D0 = np.linalg.norm(P[:, None] - P[None], axis=2)
            self.touch0 = D0 < (W0 + 2.0)
            self.same_ink = self.touch0 | (self.geo <= RATIO * D0)
            if len(self.trip):
                a, b, c = self.trip.T
                self.delta0 = P[b] - (P[a] + P[c]) / 2
        # alignment zones (in master): edge on baseline / top line
        y = P[:, 1] if n else np.zeros(0)
        self.on_base_edge = np.abs(y - W0 / 2) < 5
        self.on_top_edge = np.abs(y - (TOP - W0 / 2)) < 5
        self.on_base_end = free & (np.abs(y) < 4)
        self.on_top_end = free & (np.abs(y - TOP) < 4)

    def _curv(self, X, w):
        rmin = 0.72 * w
        for k in (max(1, int(round(0.45 * w / 14))), max(1, int(round(0.8 * w / 14)))):
            key = (k,)
            if not hasattr(self, "_tc"): self._tc = {}
            if key not in self._tc: self._tc[key] = _curv_triples(self.seqs, k)
            T = self._tc[key]
            if not len(T): continue
            a, b, c = X[T[:, 0]], X[T[:, 1]], X[T[:, 2]]
            ab = np.linalg.norm(b - a, axis=1); bc = np.linalg.norm(c - b, axis=1); ca = np.linalg.norm(a - c, axis=1)
            cross = np.abs((b - a)[:, 0] * (c - a)[:, 1] - (b - a)[:, 1] * (c - a)[:, 0])
            R = ab * bc * ca / (2 * cross + 1e-9)
            bad = R < rmin
            # skip deliberate sharp corners (flagged in the skeleton)
            if hasattr(self, "corner_mask"): bad &= ~self.corner_mask[T[:, 1]]
            if not bad.any(): continue
            mid = (a + c) / 2
            f = np.clip((rmin - R[bad]) / rmin, 0, 1)[:, None] * 0.35
            acc = np.zeros_like(X); cnt = np.zeros(len(X))
            np.add.at(acc, T[bad, 1], (mid[bad] - b[bad]) * f); np.add.at(cnt, T[bad, 1], 1)
            # push the ends outward a little so the arc opens instead of flattening into a kink
            np.add.at(acc, T[bad, 0], (a[bad] - mid[bad]) * f * 0.3); np.add.at(cnt, T[bad, 0], 1)
            np.add.at(acc, T[bad, 2], (c[bad] - mid[bad]) * f * 0.3); np.add.at(cnt, T[bad, 2], 1)
            X += acc / np.maximum(cnt, 1)[:, None]

    def gapmat(self, w):
        """counters inside one connected stroke network (loops, spiral turns) get a wider gap"""
        same_net = np.isfinite(self.geo)
        return np.where(same_net, max(12.0, 0.40 * w), gap(w))

    def radii(self, w):
        r = np.full(self.n, w / 2)
        if self.dot_idx: r[self.dot_idx] = w / 2 * 1.2
        return r

    def violations(self, X, w, tol=0.0):
        if self.n < 2: return 0.0, 0
        D = np.linalg.norm(X[:, None] - X[None], axis=2)
        r = self.radii(w)
        req = r[:, None] + r[None] + self.gapmat(w) - tol
        bad = (~self.same_ink) & (D < req)
        np.fill_diagonal(bad, False)
        if not bad.any(): return 0.0, 0
        return float((req - D)[bad].max()), int(bad.sum() // 2)

    k_len = 0.5
    margin = 5.0
    k_bend = 0.25

    def solve(self, w_target, X=None, w_start=None, step=5.0, iters=120):
        """Continuation: grow the width in small steps, settling at each one."""
        if X is None: X = self.P0.copy()
        w0 = W0 if w_start is None else w_start
        ws = list(np.arange(w0 + step, w_target, step)) + [w_target] if w_target > w0 else [w_target]
        for w in ws:
            X, v = self.relax(w, X, iters=iters)
        # final cleanup: separation dominant
        self.k_len, self.k_bend = 0.25, 0.1
        X, v = self.relax(w_target, X, iters=300)
        tries = 0
        while v > 0.0 and tries < 3:
            self.k_len, self.k_bend = 0.12 / (tries + 1), 0.05 / (tries + 1)
            X, v = self.relax(w_target, X, iters=700)
            tries += 1
        self.k_len, self.k_bend = 0.5, 0.25
        return X, v

    def relax(self, w, X=None, iters=400):
        if X is None: X = self.P0.copy()
        X = X.copy()
        n = self.n
        if n < 2: return X, 0.0
        r = self.radii(w)
        req = r[:, None] + r[None] + self.gapmat(w) + self.margin
        mask = ~self.same_ink
        np.fill_diagonal(mask, False)
        I, J = np.nonzero(np.triu(mask))
        reqIJ = req[I, J]
        lo = W0 / 2
        for it in range(iters):
            # separation
            d = X[J] - X[I]
            dist = np.linalg.norm(d, axis=1) + 1e-9
            viol = dist < reqIJ
            if viol.any():
                k = np.nonzero(viol)[0]
                corr = ((reqIJ[k] - dist[k]) / dist[k] * 0.5)[:, None] * d[k] * 0.9
                acc = np.zeros_like(X); cnt = np.zeros(n)
                np.add.at(acc, I[k], -corr); np.add.at(acc, J[k], corr)
                np.add.at(cnt, I[k], 1); np.add.at(cnt, J[k], 1)
                X += acc / np.maximum(cnt, 1)[:, None]
            # segment length
            if len(self.segs):
                a, b = self.segs.T
                d = X[b] - X[a]; L = np.linalg.norm(d, axis=1) + 1e-9
                c = ((L - self.L0) / L * 0.5 * self.k_len)[:, None] * d
                acc = np.zeros_like(X); cnt = np.zeros(n)
                np.add.at(acc, a, c); np.add.at(acc, b, -c); np.add.at(cnt, a, 1); np.add.at(cnt, b, 1)
                X += acc / np.maximum(cnt, 1)[:, None]
            # bending toward master local shape
            if len(self.trip):
                a, b, c = self.trip.T
                target = (X[a] + X[c]) / 2 + self.delta0
                acc = np.zeros_like(X); cnt = np.zeros(n)
                np.add.at(acc, b, (target - X[b]) * self.k_bend); np.add.at(cnt, b, 1)
                X += acc / np.maximum(cnt, 1)[:, None]
            # minimum curvature radius: inner edge must not fold (r >= 0.62 w)
            if it % 2 == 0:
                self._curv(X, w)
            # alignment
            if not self.mark:
                lo_ok = self.P0[:, 1] >= W0 / 2 - 3
                hi_ok = self.P0[:, 1] <= TOP - W0 / 2 + 3
                X[lo_ok, 1] = np.maximum(X[lo_ok, 1], w / 2 - 2)
                X[hi_ok, 1] = np.minimum(X[hi_ok, 1], TOP - w / 2 + 2)
                X[self.on_base_edge, 1] = w / 2
                X[self.on_top_edge, 1] = TOP - w / 2
                X[self.on_base_end, 1] = 0.0
                X[self.on_top_end, 1] = TOP
        return X, self.violations(X, w)[0]


def _curv_triples(seqs, k):
    out = []
    for idx, closed in seqs:
        m = len(idx)
        if closed:
            for i in range(m): out.append((idx[(i - k) % m], idx[i], idx[(i + k) % m]))
        else:
            for i in range(k, m - k): out.append((idx[i - k], idx[i], idx[i + k]))
    return np.array([t for t in out if len(set(t)) == 3], int).reshape(-1, 3)


def load(path):
    return json.load(open(path))


if __name__ == "__main__":
    sk = load(sys.argv[1])
    for name in sys.argv[2:]:
        G = Glyph(sk[name])
        for w in (62, 92, 124):
            v0 = G.violations(G.P0, w)
            X, v = G.relax(w)
            print(name, w, "before", v0, "after", round(v, 2), "move", round(float(np.abs(X - G.P0).max()), 1))
