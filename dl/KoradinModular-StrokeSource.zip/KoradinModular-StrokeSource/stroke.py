"""Turn centerline strokes into outlines with a uniform stroke width.

Every point count depends only on the skeleton, never on the width, so masters
at different weights stay compatible for variable-font interpolation.
Contours are quadratic (TrueType): sample points are off-curve, cap corners and
sharp corners on-curve, so curves come out smooth.
"""
import math
import numpy as np


def _unit(v):
    n = math.hypot(v[0], v[1])
    return (v[0] / n, v[1] / n) if n > 1e-9 else (0.0, 0.0)


def _normals(P, corner, closed):
    n = len(P); N = []; K = []
    for i in range(n):
        if closed:
            a, b = P[(i - 1) % n], P[(i + 1) % n]
            prev_ok = next_ok = True
        else:
            a = P[i - 1] if i > 0 else None
            b = P[i + 1] if i < n - 1 else None
        if a is None: t = _unit((b[0] - P[i][0], b[1] - P[i][1])); k = 1.0
        elif b is None: t = _unit((P[i][0] - a[0], P[i][1] - a[1])); k = 1.0
        elif corner[i]:
            u = _unit((P[i][0] - a[0], P[i][1] - a[1])); v = _unit((b[0] - P[i][0], b[1] - P[i][1]))
            t = _unit((u[0] + v[0], u[1] + v[1]))
            c = u[0] * t[0] + u[1] * t[1]          # cos of half turn
            k = 1.0 / max(c, 0.62)
        else:
            t = _unit((b[0] - a[0], b[1] - a[1])); k = 1.0
        N.append((-t[1], t[0])); K.append(k)
    return N, K


def _tan_end(P, at_start):
    if at_start: return _unit((P[0][0] - P[1][0], P[0][1] - P[1][1]))
    return _unit((P[-1][0] - P[-2][0], P[-1][1] - P[-2][1]))


def _trim(P, at_start, D):
    """Cut a polyline back by arc length D from one end, keeping the point count."""
    Q = [list(p) for p in (P if not at_start else P[::-1])]
    n = len(Q); acc = 0.0; cut = None
    for i in range(n - 1, 0, -1):
        seg = math.hypot(Q[i][0] - Q[i - 1][0], Q[i][1] - Q[i - 1][1])
        if acc + seg >= D:
            t = (D - acc) / seg if seg > 1e-9 else 0
            cut = (i, (Q[i][0] + (Q[i - 1][0] - Q[i][0]) * t, Q[i][1] + (Q[i - 1][1] - Q[i][1]) * t))
            break
        acc += seg
    if cut is None: return P
    i, c = cut
    back = _unit((Q[i - 1][0] - c[0], Q[i - 1][1] - c[1]))
    for k, j in enumerate(range(n - 1, i - 1, -1)):
        e = 0.01 * k
        Q[j] = [c[0] + back[0] * e, c[1] + back[1] * e]
    Q = [tuple(q) for q in Q]
    return Q if not at_start else Q[::-1]


def stroke_contours(P, corner, closed, ends, w, cap="butt", node_cap="round", serif=0.0, soft=False):
    """Return list of contours [[x, y, on], ...] for one stroke.
    cap: style of free ends: butt | round | square
    serif: slab half-length beyond the stroke edge (0 = no serif), applied on free ends.
    """
    h = w / 2.0
    if node_cap == "stencil" and not closed:
        D = h + 0.24 * w
        if ends[0] == "node": P = _trim(P, True, D)
        if ends[1] == "node": P = _trim(P, False, D)
    N, K = _normals(P, corner, closed)
    on = [bool(c) and not soft for c in corner]
    L = [[P[i][0] + N[i][0] * h * K[i], P[i][1] + N[i][1] * h * K[i], on[i]] for i in range(len(P))]
    R = [[P[i][0] - N[i][0] * h * K[i], P[i][1] - N[i][1] * h * K[i], on[i]] for i in range(len(P))]
    if closed:
        def area(c): return sum(c[i][0] * c[(i + 1) % len(c)][1] - c[(i + 1) % len(c)][0] * c[i][1] for i in range(len(c)))
        outer, inner = (L, R) if abs(area(L)) > abs(area(R)) else (R, L)
        if area(outer) > 0: outer = outer[::-1]      # clockwise outer
        if area(inner) < 0: inner = inner[::-1]      # counter-clockwise hole
        return [outer, inner]

    def capped(end_type, at_start):
        """points to insert going from L side to R side around an end (in contour order)."""
        i = 0 if at_start else len(P) - 1
        t = _tan_end(P, at_start)
        n = N[i]
        if at_start: n = (-n[0], -n[1])  # going from R side to L side at the start
        a = (P[i][0] + n[0] * h, P[i][1] + n[1] * h)       # current side point
        b = (P[i][0] - n[0] * h, P[i][1] - n[1] * h)       # other side point
        kind = node_cap if end_type == "node" else cap
        if kind == "stencil": kind = "butt"
        if kind == "round_in":
            # rounded end that stays inside the butt end's box
            return [[a[0], a[1], False], [P[i][0] + t[0] * h * 0.18, P[i][1] + t[1] * h * 0.18, True], [b[0], b[1], False]]
        if kind == "serif" and serif > 0:
            d = 0.42 * w
            na = (n[0] * serif, n[1] * serif)
            A = (a[0] + na[0], a[1] + na[1]); B = (b[0] - na[0], b[1] - na[1])
            slab = [[A[0], A[1], True], [B[0], B[1], True], [B[0] - t[0] * d, B[1] - t[1] * d, True], [A[0] - t[0] * d, A[1] - t[1] * d, True]]
            extra.append(slab)
            kind = "butt"
        if kind == "round":
            return [[a[0], a[1], True], [a[0] + t[0] * h, a[1] + t[1] * h, False],
                    [P[i][0] + t[0] * h, P[i][1] + t[1] * h, True],
                    [b[0] + t[0] * h, b[1] + t[1] * h, False], [b[0], b[1], True]]
        if kind == "square":
            return [[a[0], a[1], True], [a[0] + t[0] * h, a[1] + t[1] * h, True],
                    [P[i][0] + t[0] * h, P[i][1] + t[1] * h, True],
                    [b[0] + t[0] * h, b[1] + t[1] * h, True], [b[0], b[1], True]]
        if False:
            s = serif; d = 0
            # slab: perpendicular bar at the end, depth d back from the end
            a2 = (a[0] - t[0] * d, a[1] - t[1] * d); b2 = (b[0] - t[0] * d, b[1] - t[1] * d)
            na = (n[0] * s, n[1] * s)
            return [[a2[0], a2[1], True], [a2[0] + na[0], a2[1] + na[1], True], [a[0] + na[0], a[1] + na[1], True],
                    [P[i][0], P[i][1], True],
                    [b[0] - na[0], b[1] - na[1], True], [b2[0] - na[0], b2[1] - na[1], True], [b2[0], b2[1], True]]
        # butt: same point count as the others for compatibility across styles is not needed
        return [[a[0], a[1], True], [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, True], [b[0], b[1], True]]

    extra = []
    c = []
    c += capped(ends[0], True)            # from R0 to L0
    c += [list(p) for p in L[1:-1]]
    c += capped(ends[1], False)           # from Ln to Rn
    c += [list(p) for p in R[-2:0:-1]]
    # orientation: make clockwise
    ar = sum(c[i][0] * c[(i + 1) % len(c)][1] - c[(i + 1) % len(c)][0] * c[i][1] for i in range(len(c)))
    if ar > 0: c = c[::-1]
    out = [c]
    for e in extra:
        ae = sum(e[i][0] * e[(i + 1) % len(e)][1] - e[(i + 1) % len(e)][0] * e[i][1] for i in range(len(e)))
        out.append(e[::-1] if ae > 0 else e)
    return out


def dot_contour(x, y, w, cap="butt"):
    h = w / 2.0
    if cap == "round":
        c = [[x - h, y, True], [x - h, y + h, False], [x, y + h, True], [x + h, y + h, False],
             [x + h, y, True], [x + h, y - h, False], [x, y - h, True], [x - h, y - h, False]]
    else:
        c = [[x - h, y - h, True], [x - h, y + h, True], [x + h, y + h, True], [x + h, y - h, True]]
    ar = sum(c[i][0] * c[(i + 1) % len(c)][1] - c[(i + 1) % len(c)][0] * c[i][1] for i in range(len(c)))
    if ar > 0: c = c[::-1]
    return c


def glyph_contours(g, pos, w, style):
    """g: skeleton entry, pos: particle positions (n,2), w: stroke width, style: dict."""
    out = []
    for s in g["strokes"]:
        P = [tuple(pos[i]) for i in s["idx"]]
        if len(P) < 2: continue
        out += stroke_contours(P, s["corner"], s["closed"], s["ends"], w,
                               cap=style.get("cap", "butt"), node_cap=style.get("node_cap", "round"),
                               serif=style.get("serif", 0.0) * w, soft=style.get("soft", False))
    for (x, y, size) in g.get("dots_pos", g["dots"]):
        out.append(dot_contour(x, y, w * style.get("dot", 1.0), style.get("dotcap", "butt")))
    return out
