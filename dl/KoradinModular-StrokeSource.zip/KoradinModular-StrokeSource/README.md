# Kɔradin Modular, stroke edition

Koradin Dua redrawn as centerline strokes of one width. Every weight, width and slant is
generated from these strokes.

## The rule

At any weight, no stroke may touch another stroke, or another part of itself, unless it
already touched in Koradin Dua. The solver enforces it like this:

- Two points on the same piece of ink are exempt: the path between them along the stroke is
  less than 1.5 times their straight distance (straight runs, right-angle corners, junctions).
- Every other pair must stay at least one stroke width plus a gap apart. The gap is 33% of the
  stroke width between separate strokes, and 40% inside one stroke network (loops, spiral turns).
- Curves can't bend tighter than 0.72 × stroke width, so inner edges never fold.
- Strokes resting on the baseline or the top line keep their outer edge on the line.
- Spirals and loops unwind and the glyph widens as weight grows. Height stays fixed at 0 to 700.

Black is capped at a stroke of 98 units (the master is 62). Above that, the tightest spirals
(2.5 nested turns in 700 units) can't satisfy the rule.

Status: 254 of 259 glyphs pass at every weight, including the in-between ones.
Exceptions: `wu.liga` and `vi.liga` touch briefly at one in-between weight, and `exclam`
(a stack of rings) has no room at Black. `c` and `q` are Latin fallback glyphs the transcriber
never outputs.

## Files

- `src_svg/` one SVG per glyph. Each `<path>` is one stroke's centerline. Each `<circle>` is a dot.
  Edit in Illustrator, Figma or Inkscape. Keep paths unfilled. A stroke end that sits within
  3 units of another stroke becomes a junction.
- `make.sh` rebuilds the fonts from `src_svg/`. Run `./make.sh --from-otf` to re-trace from Koradin.otf.
- `skel.py` traces centerlines, `fix.py` restores short stubs, `relax.py` holds the rule and solver,
  `masters.py` solves 8 weight masters, `straighten.py` fixes in-between weights,
  `stroke.py` turns strokes into outlines (butt, rounded, serif, stencil), `build2.py` builds the fonts.

## Axes

- `wght` 100 to 900 (stroke 22 to 98 units, 8 masters)
- `wdth` 100 to 125
- `slnt` -10 to 0
