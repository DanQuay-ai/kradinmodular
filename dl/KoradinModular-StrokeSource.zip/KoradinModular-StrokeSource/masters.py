"""Solve collision-safe skeleton positions for every glyph at each weight master,
then verify the rule on interpolated in-between weights."""
import sys, json, time
import numpy as np
from multiprocessing import Pool
sys.path.insert(0, ".")
from relax import Glyph, W0

MASTERS = {"thin": 22.0, "regular": 62.0, "w68": 68.0, "w74": 74.0, "bold": 80.0, "w86": 86.0, "w92": 92.0, "black": 98.0}
MARKS = {"m", "n", "ng.liga"}
SK = None

def work(name):
    g = SK[name]
    G = Glyph(g, mark=name in MARKS)
    res = {}
    if G.n == 0 or name in MARKS:
        for k in MASTERS: res[k] = G.P0.tolist()
        return name, res, 0.0
    Xr, _ = G.solve(MASTERS["regular"], G.P0.copy(), w_start=W0)
    Xt, _ = G.relax(MASTERS["thin"], Xr.copy(), iters=60)
    res = {"thin": Xt, "regular": Xr}
    X, prev = Xr, MASTERS["regular"]
    for k in ["w68", "w74", "bold", "w86", "w92", "black"]:
        X, _ = G.solve(MASTERS[k], X, w_start=prev, step=3.0); prev = MASTERS[k]; res[k] = X
    # verify interpolation between neighbouring masters
    worst = 0.0
    seq = [(k, res[k]) for k in MASTERS]
    res = {k: v.tolist() for k, v in res.items()}
    for (n1, A), (n2, B) in zip(seq, seq[1:]):
        for t in np.linspace(0, 1, 9):
            w = MASTERS[n1] + (MASTERS[n2] - MASTERS[n1]) * t
            X = A + (B - A) * t
            v, _ = G.violations(X, w)
            worst = max(worst, v)
    return name, res, worst

def init(skf):
    global SK
    SK = json.load(open(skf))

if __name__ == "__main__":
    skf, out = sys.argv[1], sys.argv[2]
    init(skf)
    t0 = time.time()
    with Pool(2, initializer=init, initargs=(skf,)) as p:
        results = p.map(work, list(SK.keys()), chunksize=4)
    data = {n: r for n, r, _ in results}
    report = {n: round(v, 2) for n, _, v in results}
    json.dump({"masters": MASTERS, "pos": data, "worst": report}, open(out, "w"))
    vals = np.array(list(report.values()))
    print("time", round(time.time() - t0), "s; glyphs", len(vals), "clean", int((vals < 1).sum()),
          "1-4 units", int(((vals >= 1) & (vals < 4)).sum()), ">=4", int((vals >= 4).sum()))
    print(sorted(report.items(), key=lambda x: -x[1])[:20])
