"""Extract centerline strokes (skeletons) from the Koradin Dua outlines.

Output: skeleton.json, one entry per glyph:
  particles: [[x, y], ...]            shared points (junctions are single particles)
  strokes:   [{"idx": [...], "corner": [...], "closed": bool, "ends": [type0, type1]}]
             end type: "free" (true stroke end, butt cap) or "node" (ends inside a junction)
  dots:      [[x, y, size]]
  adv, lsb, w (measured stroke width)
"""
import sys, json, math
import numpy as np
from fontTools.ttLib import TTFont
from fontTools.pens.freetypePen import FreeTypePen
from fontTools.pens.boundsPen import BoundsPen
from skimage.morphology import skeletonize
from scipy import ndimage
from skan import Skeleton

PAD = 24
SPACING = 14.0


def raster(gs, name):
    bp = BoundsPen(gs); gs[name].draw(bp)
    if bp.bounds is None: return None
    x0, y0, x1, y1 = bp.bounds
    W = int(math.ceil(x1 - x0)) + 2 * PAD; H = int(math.ceil(y1 - y0)) + 2 * PAD
    ox, oy = PAD - math.floor(x0), PAD - math.floor(y0)
    pen = FreeTypePen(gs); gs[name].draw(pen)
    a = pen.array(width=W, height=H, transform=(1, 0, 0, 1, ox, oy))
    # array row 0 is the top: convert to font coords: x = col - ox, y = (H - row) - oy
    return a > 0.5, ox, oy, H


def to_font(rc, ox, oy, H):
    r, c = rc[..., 0], rc[..., 1]
    return np.stack([c + 0.5 - ox, (H - r - 0.5) - oy], -1)


def plen(p):
    return float(np.sum(np.linalg.norm(np.diff(p, axis=0), axis=1))) if len(p) > 1 else 0.0


def unit(v):
    n = np.linalg.norm(v); return v / n if n > 1e-9 else v


def extract(gs, name):
    R = raster(gs, name)
    if R is None: return None
    mask, ox, oy, H = R
    dt = ndimage.distance_transform_edt(mask)
    sk = skeletonize(mask)
    lab, ncomp = ndimage.label(mask, structure=np.ones((3, 3)))
    widths = 2 * dt[sk]
    w_est = float(np.median(widths)) if widths.size else 0
    dots, edges = [], []
    # dots / tiny components
    for ci in range(1, ncomp + 1):
        comp = lab == ci
        skc = sk & comp
        n = skc.sum()
        ys, xs = np.nonzero(comp)
        ext = max(xs.max() - xs.min(), ys.max() - ys.min())
        if n < 3 or ext < 1.6 * 2 * dt[comp].max():
            cy, cx = ys.mean(), xs.mean()
            pt = to_font(np.array([[cy, cx]]), ox, oy, H)[0]
            dots.append([float(pt[0]), float(pt[1]), float(ext)])
            sk[comp] = False
    if sk.sum() < 2:
        return dict(particles=[], strokes=[], dots=dots, w=w_est)

    # ---- graph from skan
    S = Skeleton(sk)
    paths = []
    for i in range(S.n_paths):
        coords = S.path_coordinates(i)
        ids = S.path(i)
        paths.append([np.array(coords, float), int(ids[0]), int(ids[-1])])
    deg = np.bincount(np.concatenate([[p[1], p[2]] for p in paths]))

    def node_key(i):
        return i

    # cluster nearby junction pixels into one node
    pix = {}
    for p in paths:
        for k, ii in ((0, p[1]), (-1, p[2])):
            pix[ii] = p[0][k]
    ids = list(pix.keys())
    parent = {i: i for i in ids}
    def find(i):
        while parent[i] != i: parent[i] = parent[parent[i]]; i = parent[i]
        return i
    for a in ids:
        for b in ids:
            if a < b and np.linalg.norm(pix[a] - pix[b]) <= 3.0 and deg[a] > 1 and deg[b] > 1:
                parent[find(a)] = find(b)
    E = []
    for p in paths:
        a, b = find(p[1]), find(p[2])
        if a == b and plen(p[0]) < 8: continue
        E.append({"pts": p[0], "a": a, "b": b})

    def degrees():
        d = {}
        for e in E:
            d[e["a"]] = d.get(e["a"], 0) + 1; d[e["b"]] = d.get(e["b"], 0) + 1
        return d

    def edge_dir(e, node):
        p = e["pts"] if e["a"] == node else e["pts"][::-1]
        k = min(len(p) - 1, 14)
        return unit(p[k] - p[0])

    def is_stub(e, end, other, L):
        """short branch sticking out perpendicular from a straight stroke = a real stub, not noise"""
        if L < 0.45 * w_est: return False
        j = e[other]
        inc = [x for x in E if x is not e and (x["a"] == j or x["b"] == j)]
        if len(inc) != 2: return False
        d1, d2 = edge_dir(inc[0], j), edge_dir(inc[1], j)
        if float(np.dot(d1, d2)) > -0.88: return False
        de = edge_dir(e, j)
        return abs(float(np.dot(de, d1))) < 0.55

    # ---- prune spurs (terminal edges shorter than the local stroke width)
    for _ in range(4):
        d = degrees(); changed = False
        for e in list(E):
            for end, other in (("a", "b"), ("b", "a")):
                if d.get(e[end], 0) == 1 and d.get(e[other], 0) >= 3:
                    L = plen(e["pts"])
                    jr = e["pts"][-1 if end == "a" else 0].astype(int)
                    wl = 2 * dt[jr[0], jr[1]]
                    if L < 0.74 * wl and not is_stub(e, end, other, L):
                        E[:] = [x for x in E if x is not e]; changed = True; break
        # merge degree-2 nodes
        d = degrees()
        merged = True
        while merged:
            merged = False
            d = degrees()
            for n, k in d.items():
                if k != 2: continue
                es = [e for e in E if e["a"] == n or e["b"] == n]
                if len(es) != 2 or es[0] is es[1]: continue
                e1, e2 = es
                p1 = e1["pts"] if e1["b"] == n else e1["pts"][::-1]
                s1 = e1["a"] if e1["b"] == n else e1["b"]
                p2 = e2["pts"] if e2["a"] == n else e2["pts"][::-1]
                s2 = e2["b"] if e2["a"] == n else e2["a"]
                E[:] = [x for x in E if x is not e1 and x is not e2]
                E.append({"pts": np.concatenate([p1, p2[1:]]), "a": s1, "b": s2})
                merged = True; changed = True
                break
        if not changed: break

    d = degrees()
    # convert to font coords
    for e in E:
        e["f"] = to_font(e["pts"], ox, oy, H)
    nodepos = {}
    for e in E:
        nodepos.setdefault(e["a"], e["f"][0]); nodepos.setdefault(e["b"], e["f"][-1])
    # junction node position: mean of incident ends
    for n in nodepos:
        ends = [e["f"][0] for e in E if e["a"] == n] + [e["f"][-1] for e in E if e["b"] == n]
        nodepos[n] = np.mean(ends, 0)
    for e in E:
        e["f"][0] = nodepos[e["a"]]; e["f"][-1] = nodepos[e["b"]]

    # ---- extend free ends to the true stroke end
    def march(p, t):
        q = p.copy()
        for _ in range(200):
            nq = q + t * 0.5
            c = int(round(nq[0] - 0.5 + ox)); r = int(round(H - (nq[1] + 0.5) - oy + 0));
            r = int(round(H - oy - nq[1] - 0.5))
            if r < 0 or c < 0 or r >= mask.shape[0] or c >= mask.shape[1] or not mask[r, c]: break
            q = nq
        return q
    for e in E:
        for end in ("a", "b"):
            if d[e[end]] == 1:
                f = e["f"]
                seg = f[:min(len(f), 18)] if end == "a" else f[::-1][:min(len(f), 18)]
                if len(seg) < 3: continue
                t = unit(seg[0] - seg[-1])
                q = march(seg[0], t)
                if end == "a": e["f"] = np.concatenate([[q], f])
                else: e["f"] = np.concatenate([f, [q]])

    # ---- pair edges through junctions into continuous strokes
    def tangent_out(e, n):
        f = e["f"] if e["a"] == n else e["f"][::-1]
        k = min(len(f) - 1, 16)
        return unit(f[k] - f[0])
    cont = {}   # (edge_id, end) -> (edge_id, end)
    for n, k in d.items():
        if k < 3: continue
        inc = []
        for i, e in enumerate(E):
            if e["a"] == n: inc.append((i, "a"))
            if e["b"] == n: inc.append((i, "b"))
        cand = []
        for x in range(len(inc)):
            for y in range(x + 1, len(inc)):
                if inc[x][0] == inc[y][0]: continue
                c = float(np.dot(tangent_out(E[inc[x][0]], n), tangent_out(E[inc[y][0]], n)))
                cand.append((c, inc[x], inc[y]))
        cand.sort()
        used = set()
        for c, u, v in cand:
            if c > -0.55: break         # angle between outgoing tangents must exceed ~123 deg
            if u in used or v in used: continue
            cont[u] = v; cont[v] = u; used |= {u, v}

    # ---- walk chains
    visited = set(); chains = []
    def walk(i, start_end):
        seq = []
        cur, ent = i, start_end
        while True:
            visited.add(cur)
            e = E[cur]
            pts = e["f"] if ent == "a" else e["f"][::-1]
            nd = [e["a"], e["b"]] if ent == "a" else [e["b"], e["a"]]
            seq.append((pts, nd))
            ex = "b" if ent == "a" else "a"
            nxt = cont.get((cur, ex))
            if nxt is None or nxt[0] in visited: return seq, (nxt is not None)
            cur, ent = nxt
    # start at chain ends: free ends or non-continued junction ends
    for i, e in enumerate(E):
        for end in ("a", "b"):
            if i in visited: continue
            if (i, end) not in cont:
                chains.append(walk(i, end))
    for i, e in enumerate(E):
        if i not in visited:
            chains.append(walk(i, "a"))

    # ---- particles
    particles = []; pid_of_node = {}
    def node_pid(n):
        if n not in pid_of_node:
            pid_of_node[n] = len(particles); particles.append(nodepos[n].tolist())
        return pid_of_node[n]

    strokes = []
    for seq, closed in chains:
        idx, corner = [], []
        first_node = seq[0][1][0]
        ends = []
        for si, (pts, nd) in enumerate(seq):
            a_free = d[nd[0]] == 1; b_free = d[nd[1]] == 1
            # resample this edge with corners preserved
            res, cf = resample(pts)
            # first point: node particle unless free end
            if si == 0:
                if a_free:
                    idx.append(len(particles)); particles.append(res[0].tolist()); corner.append(True)
                else:
                    idx.append(node_pid(nd[0])); corner.append(cf[0])
            for k in range(1, len(res) - 1):
                idx.append(len(particles)); particles.append(res[k].tolist()); corner.append(cf[k])
            if b_free:
                idx.append(len(particles)); particles.append(res[-1].tolist()); corner.append(True)
            else:
                idx.append(node_pid(nd[1])); corner.append(cf[-1])
            if si == 0: ends.append("free" if a_free else "node")
            if si == len(seq) - 1: ends.append("free" if b_free else "node")
        if closed and idx[0] == idx[-1]:
            idx = idx[:-1]; corner = corner[:-1]
        strokes.append({"idx": idx, "corner": corner, "closed": bool(closed and len(idx) > 2 and ends == ["node", "node"]), "ends": ends})
    return dict(particles=particles, strokes=strokes, dots=dots, w=w_est)


def resample(pts):
    """Smooth a pixel path, keep sharp corners, resample at ~SPACING units. Returns (points, corner_flags)."""
    pts = np.asarray(pts, float)
    # remove duplicate points
    keep = np.concatenate([[True], np.linalg.norm(np.diff(pts, axis=0), axis=1) > 1e-6])
    pts = pts[keep]
    if len(pts) < 3: return pts, [False] * len(pts)
    s = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(pts, axis=0), axis=1))])
    L = s[-1]
    # corner detection: angle between mean directions of windows before/after
    win = 11.0
    cidx = []
    ang = np.zeros(len(pts))
    for i in range(len(pts)):
        if s[i] < win or L - s[i] < win: continue
        a = np.interp(s[i] - win, s, pts[:, 0]), np.interp(s[i] - win, s, pts[:, 1])
        b = np.interp(s[i] + win, s, pts[:, 0]), np.interp(s[i] + win, s, pts[:, 1])
        u = unit(pts[i] - np.array(a)); v = unit(np.array(b) - pts[i])
        ang[i] = math.degrees(math.acos(max(-1, min(1, float(np.dot(u, v))))))
    i = 0
    while i < len(pts):
        if ang[i] > 42:
            j = i
            while j + 1 < len(pts) and ang[j + 1] > 42: j += 1
            k = i + int(np.argmax(ang[i:j + 1]))
            cidx.append(k); i = j + 1
        else: i += 1
    cuts = [0] + cidx + [len(pts) - 1]
    out, flags = [], []
    for ci in range(len(cuts) - 1):
        a, b = cuts[ci], cuts[ci + 1]
        seg = pts[a:b + 1]
        if len(seg) >= 5:
            sm = seg.copy()
            sm[1:-1] = np.stack([ndimage.gaussian_filter1d(seg[:, 0], 2.5, mode="nearest"),
                                 ndimage.gaussian_filter1d(seg[:, 1], 2.5, mode="nearest")], -1)[1:-1]
            seg = sm
        ss = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(seg, axis=0), axis=1))])
        n = max(1, int(math.ceil(ss[-1] / SPACING)))
        t = np.linspace(0, ss[-1], n + 1)
        rs = np.stack([np.interp(t, ss, seg[:, 0]), np.interp(t, ss, seg[:, 1])], -1)
        if ci > 0: rs = rs[1:]
        for k, p in enumerate(rs):
            out.append(p)
            flags.append(False)
        if ci < len(cuts) - 2: flags[-1] = True
    flags[0] = False; flags[-1] = False
    return np.array(out), flags


def main():
    src, outp = sys.argv[1], sys.argv[2]
    f = TTFont(src); gs = f.getGlyphSet()
    data = {}
    for g in f.getGlyphOrder():
        adv, lsb = f["hmtx"][g]
        r = None
        try: r = extract(gs, g)
        except Exception as ex: print("ERR", g, ex)
        if r is None: r = dict(particles=[], strokes=[], dots=[], w=0)
        r["adv"] = adv; r["lsb"] = lsb
        data[g] = r
    json.dump(data, open(outp, "w"))
    print("glyphs", len(data), "strokes", sum(len(v["strokes"]) for v in data.values()),
          "particles", sum(len(v["particles"]) for v in data.values()))


if __name__ == "__main__":
    main()
