"""Measure how a scaled part sits inside a derived sign:
  y-row  = mini i  + vowel      w-row = mini ɔ + vowel
  ny/ni  = ni sign + medium vowel
For each vowel: best scale s and offset (dx, dy) of the part, and the vowel's offset."""
import json, sys
import numpy as np
from fontTools.ttLib import TTFont
from fontTools.pens.freetypePen import FreeTypePen
from scipy import ndimage

f = TTFont(sys.argv[1]); gs = f.getGlyphSet()
S = 0.25; W, H, OX, OY = 400, 260, 40, 50   # raster in quarter units; origin (OX,OY) px
VK = {"a": "a", "e": "e", "ɛ": "eopen", "i": "i", "o": "o", "ɔ": "oopen", "u": "u"}

def ras(n, s=1.0, dx=0.0, dy=0.0):
    pen = FreeTypePen(gs); gs[n].draw(pen)
    t = (S * s, 0, 0, S * s, OX + dx * S, OY + dy * S)
    return pen.array(width=W, height=H, transform=t) > 0.5

def best_shift(target, part):
    T = np.fft.rfft2(target.astype(float)); P = np.fft.rfft2(part.astype(float))
    c = np.fft.irfft2(T * np.conj(P), s=target.shape)
    k = np.unravel_index(np.argmax(c), c.shape)
    dy = k[0] if k[0] <= H // 2 else k[0] - H; dx = k[1] if k[1] <= W // 2 else k[1] - W
    return int(dy), int(dx), float(c[k])

def place(target, part_name, scales, exclude=None):
    """best (s, dx, dy, iou) of scaled part inside target (minus exclude)"""
    tgt = target & ~ndimage.binary_dilation(exclude, iterations=2) if exclude is not None else target
    best = None
    for s in scales:
        p = ras(part_name, s)
        dy, dx, inter = best_shift(tgt, p)
        P = np.roll(np.roll(p, dy, 0), dx, 1)
        iou = (P & tgt).sum() / max(1, (P | tgt).sum())
        cov = (P & target).sum() / max(1, P.sum())
        if best is None or cov + iou > best[4] + best[3]:
            # font-unit offset: raster shift dx px -> dx/S units; y flips
            best = (s, dx / S, -dy / S, float(iou), float(cov))
    return best

out = {"glide_y": {}, "glide_w": {}, "ny": {}}
for v, k in VK.items():
    for row, part, key in (("y", "i", "glide_y"), ("w", "oopen", "glide_w")):
        n = f"{row}{k}.liga"
        T = ras(n)
        # vowel placement (full size) first
        vs = place(T, k, [1.0])
        Vm = np.roll(np.roll(ras(k), int(-vs[2] * S), 0), int(vs[1] * S), 1)
        ps = place(T, part, np.arange(0.28, 0.66, 0.02), exclude=Vm)
        out[key][v] = {"vowel": {"dx": vs[1], "dy": vs[2], "cov": round(vs[4], 3)},
                       "part": {"s": round(ps[0], 2), "dx": ps[1], "dy": ps[2], "cov": round(ps[4], 3), "iou": round(ps[3], 3)}}
    n = f"ny{k}.liga"
    T = ras(n)
    ns = place(T, "ni.liga", [1.0])
    Nm = np.roll(np.roll(ras("ni.liga"), int(-ns[2] * S), 0), int(ns[1] * S), 1)
    vsm = place(T, k, np.arange(0.40, 0.92, 0.02), exclude=Nm)
    out["ny"][v] = {"ni": {"dx": ns[1], "dy": ns[2], "cov": round(ns[4], 3)},
                    "vowel": {"s": round(vsm[0], 2), "dx": vsm[1], "dy": vsm[2], "cov": round(vsm[4], 3), "iou": round(vsm[3], 3)}}
    print(v, "y:", out["glide_y"][v]["part"], "| w:", out["glide_w"][v]["part"], "| ny vowel:", out["ny"][v]["vowel"])
json.dump(out, open(sys.argv[2], "w"), ensure_ascii=False, indent=1)
