"""Fix interpolation dips: make each master segment pass through a solved midpoint."""
import sys, json
import numpy as np
sys.path.insert(0, ".")
from relax import Glyph

sk = json.load(open(sys.argv[1])); M = json.load(open(sys.argv[2]))
ms = M["masters"]; keys = list(ms.keys())

def seg_worst(G, A, B, wa, wb):
    worst, tw = 0.0, None
    for t in np.linspace(0, 1, 13):
        v, _ = G.violations(A + (B - A) * t, wa + (wb - wa) * t)
        if v > worst: worst, tw = v, t
    return worst, tw

for name, wv in sorted(M["worst"].items(), key=lambda x: -x[1]):
    if wv < 0.5 or name in ("exclam",): continue
    G = Glyph(sk[name]); P = {k: np.array(v) for k, v in M["pos"][name].items()}
    for _ in range(4):
        changed = False
        for a, b in zip(keys, keys[1:]):
            worst, t = seg_worst(G, P[a], P[b], ms[a], ms[b])
            if worst < 0.5: continue
            wm = ms[a] + (ms[b] - ms[a]) * t
            Xm, _ = G.solve(wm, P[a] + (P[b] - P[a]) * t, w_start=ms[a], step=2.0)
            # re-aim master b through the solved midpoint, then settle it at its own width
            target = P[a] + (Xm - P[a]) / max(t, 0.1)
            Xb, _ = G.relax(ms[b], target, iters=500)
            if G.violations(Xb, ms[b])[0] < 0.5:
                P[b] = Xb; changed = True
        if not changed: break
    total = max(seg_worst(G, P[a], P[b], ms[a], ms[b])[0] for a, b in zip(keys, keys[1:]))
    print(name, "before", wv, "after", round(total, 2), flush=True)
    M["pos"][name] = {k: v.tolist() for k, v in P.items()}
    M["worst"][name] = round(total, 2)
json.dump(M, open(sys.argv[2], "w"))
vals = np.array(list(M["worst"].values()))
print("clean", int((vals < 1).sum()), "of", len(vals))
