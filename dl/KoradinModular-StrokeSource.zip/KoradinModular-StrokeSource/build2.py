"""Koradin Modular (stroke edition): build variable fonts from skeleton + solved masters.

python3 -I build2.py <source.otf> skeleton.json masters.json <outdir>
"""
import sys, os, json, math, copy
import numpy as np
from fontTools.ttLib import TTFont, newTable
from fontTools.pens.ttGlyphPen import TTGlyphPen
from fontTools.pens.cu2quPen import Cu2QuPen
from fontTools.designspaceLib import DesignSpaceDocument, AxisDescriptor, SourceDescriptor
from fontTools import varLib
from fontTools.varLib import instancer
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from stroke import glyph_contours

SRC, SKF, MF, OUT = sys.argv[1:5]
os.makedirs(OUT, exist_ok=True)
TMP = os.path.join(OUT, "_masters"); os.makedirs(TMP, exist_ok=True)
SK = json.load(open(SKF)); M = json.load(open(MF))
WMAP = {"thin": 100, "regular": 400, "w68": 480, "w74": 560, "bold": 640, "w86": 720, "w92": 810, "black": 900}
MARKS = {"m", "n", "ng.liga"}
MARK_RATIO = 0.6
WIDE = 1.25
SLANT = 10.0

STYLES = {
    "Regular": {"cap": "butt", "node_cap": "round"},
    "Rounded": {"cap": "round_in", "node_cap": "round", "soft": True, "dotcap": "round"},
    "Serif":   {"cap": "serif", "node_cap": "round", "serif": 0.16},
    "Stencil": {"cap": "butt", "node_cap": "stencil"},
}


def otf_to_ttf(path):
    f = TTFont(path); gs = f.getGlyphSet()
    glyf = newTable("glyf"); glyf.glyphOrder = f.getGlyphOrder(); glyf.glyphs = {}
    for name in f.getGlyphOrder():
        pen = TTGlyphPen(None); gs[name].draw(Cu2QuPen(pen, max_err=1.0, reverse_direction=True)); glyf[name] = pen.glyph()
    f["loca"] = newTable("loca"); f["glyf"] = glyf
    del f["CFF "]
    f["maxp"].tableVersion = 0x00010000
    for k in ("maxZones", "maxTwilightPoints", "maxStorage", "maxFunctionDefs", "maxInstructionDefs",
              "maxStackElements", "maxSizeOfInstructions", "maxComponentElements", "maxComponentDepth"):
        setattr(f["maxp"], k, 0)
    f["maxp"].maxZones = 1
    f["head"].glyphDataFormat = 0
    f["post"].formatType = 2.0; f["post"].extraNames = []; f["post"].mapping = {}
    f.sfntVersion = "\x00\x01\x00\x00"
    return f


def build_glyph(contours):
    pen = TTGlyphPen(None)
    for c in contours:
        if len(c) < 3: continue
        k = next((i for i, p in enumerate(c) if p[2]), None)
        if k is None:
            pen.qCurveTo(*[(round(p[0]), round(p[1])) for p in c], None); pen.closePath(); continue
        c = c[k:] + c[:k]
        pen.moveTo((round(c[0][0]), round(c[0][1]))); buf = []
        for p in c[1:] + [c[0]]:
            pt = (round(p[0]), round(p[1]))
            if p[2]:
                if buf: pen.qCurveTo(*buf, pt); buf = []
                else: pen.lineTo(pt)
            else: buf.append(pt)
        if buf: pen.qCurveTo(*buf, (round(c[0][0]), round(c[0][1])))
        pen.closePath()
    g = pen.glyph()
    # overlapping contours are intended: flag them so rasterizers use nonzero fill
    if g.numberOfContours > 0:
        g.flags[0] |= 0x40
    return g


def set_names(f, family, style="Regular"):
    nm = f["name"]
    for nid in (1, 2, 3, 4, 6, 16, 17, 25): nm.removeNames(nameID=nid)
    ps = (family + "-" + style).replace(" ", "")
    for nid, val in ((1, family), (2, style), (3, ps + "-2026"), (4, f"{family} {style}"), (6, ps)):
        nm.setName(val, nid, 3, 1, 0x409); nm.setName(val, nid, 1, 0, 0)


def master_font(base, style, key, w, xscale=1.0, skew=0.0):
    f = copy.deepcopy(base)
    glyf, hmtx = f["glyf"], f["hmtx"]
    st = STYLES[style]
    ga = {}
    for name in f.getGlyphOrder():
        g = SK[name]
        adv0, lsb0 = base["hmtx"][name]
        if not g["strokes"] and not g["dots"]:
            glyf[name] = build_glyph([]); hmtx[name] = (round(adv0 * (1 + (w - 62) / 400) * xscale), 0); ga[name] = hmtx[name][0]; continue
        X = np.array(M["pos"][name][key], float)
        ww = w
        if name in MARKS:
            ww = w * MARK_RATIO
            X = X.copy(); X[:, 1] -= (ww - 62 * MARK_RATIO) / 2       # keep the mark's top edge
        n_part = len(g["particles"])
        X = X.copy()
        if xscale != 1.0: X[:, 0] *= xscale
        if skew: X[:, 0] += (X[:, 1] - 350) * skew
        gg = dict(g); gg["dots_pos"] = [[X[n_part + i][0], X[n_part + i][1], 0] for i in range(len(g["dots"]))]
        cont = glyph_contours(gg, X, ww, st)
        if name in MARKS:
            glyf[name] = build_glyph(cont); glyf[name].recalcBounds(glyf)
            hmtx[name] = (0, glyf[name].xMin if cont else 0); ga[name] = 0
            continue
        # metrics: keep original side bearings around the new ink
        xs = [p[0] for c in cont for p in c]
        x0, x1 = min(xs), max(xs)
        # original ink box
        o = base["glyf"][name]; o.recalcBounds(base["glyf"])
        rsb0 = adv0 - o.xMax if o.numberOfContours else 0
        shift = lsb0 - x0
        cont = [[[p[0] + shift, p[1], p[2]] for p in c] for c in cont]
        gl = build_glyph(cont); glyf[name] = gl; gl.recalcBounds(glyf)
        adv = round((x1 - x0) + lsb0 + rsb0)
        hmtx[name] = (adv, gl.xMin); ga[name] = adv
    # base anchors at the centre of the new advance
    gpos = f["GPOS"].table
    for lk in gpos.LookupList.Lookup:
        for stb in lk.SubTable:
            if lk.LookupType == 4:
                for gname, rec in zip(stb.BaseCoverage.glyphs, stb.BaseArray.BaseRecord):
                    for a in rec.BaseAnchor:
                        if a is not None and gname in ga: a.XCoordinate = round(ga[gname] / 2)
    return f


def main():
    base = otf_to_ttf(SRC)
    ms = M["masters"]
    report = {}
    for style in STYLES:
        fam = "Koradin Modular" if style == "Regular" else f"Koradin Modular {style}"
        ds = DesignSpaceDocument()
        for tag, nm_, mn, df, mx in (("wght", "Weight", 100, 400, 900), ("wdth", "Width", 100, 100, 125), ("slnt", "Slant", -10, 0, 0)):
            a = AxisDescriptor(); a.tag, a.name, a.minimum, a.default, a.maximum = tag, nm_, mn, df, mx
            if tag == "wght": a.map = [(WMAP[k], ms[k]) for k in WMAP]
            ds.addAxis(a)
        srcs = [(k, ms[k], 1.0, 0.0, {"Weight": ms[k], "Width": 100, "Slant": 0}) for k in WMAP]
        srcs += [("wide", 62.0, WIDE, 0.0, {"Weight": 62.0, "Width": 125, "Slant": 0}),
                 ("slant", 62.0, 1.0, math.tan(math.radians(SLANT)), {"Weight": 62.0, "Width": 100, "Slant": -10})]
        for name, w, xs, sk, loc in srcs:
            key = "regular" if name in ("wide", "slant") else name
            m = master_font(base, style, key, w, xs, sk)
            set_names(m, fam)
            p = os.path.join(TMP, f"{style}-{name}.ttf"); m.save(p)
            s = SourceDescriptor(); s.path = p; s.location = loc; s.name = name; ds.addSource(s)
        vf, _, _ = varLib.build(ds, exclude=["STAT"])
        set_names(vf, fam)
        vpath = os.path.join(OUT, f"KoradinModular-{style}-VF.ttf"); vf.save(vpath)
        vf.flavor = "woff2"; vf.save(os.path.join(OUT, f"KoradinModular-{style}-VF.woff2"))
        for wname, wv in (("Thin", 100), ("Light", 250), ("Regular", 400), ("Bold", 700), ("Black", 900)):
            inst = instancer.instantiateVariableFont(TTFont(vpath), {"wght": wv, "wdth": 100, "slnt": 0})
            set_names(inst, fam, wname)
            inst.save(os.path.join(OUT, f"KoradinModular-{style}-{wname}.ttf"))
        report[style] = os.path.getsize(vpath)
        print("built", style, report[style], flush=True)


if __name__ == "__main__":
    main()
