"""Kɔradin construction grammar -> skeleton2.json

Radicals (vowels, p t d k f s n r rows, kw) are traced from Koradin Dua and cleaned:
no stubs, no flag terminals, bars snapped to guides, stems straightened.
Every other row is COMPOSED:
  bar rows      ky tw | gy(=j) dw | hy z | v hw | l | g | m | b | h
                = radical + modifier bar snapped to the top / mid / base guide
  bracket rows  kp = p + bracket ) ;  gb = b + bracket }
  glide rows    y = mini i (0.52) + vowel ;  w = mini ɔ (0.34) + vowel   (top-aligned, left)
  ny = ni       = ni sign + medium vowel (0.82, o: 0.62)
  my            = ny + mid bar
"""
import json, math, copy, sys
import numpy as np

SK = json.load(open("skeleton.json"))
MOD = json.load(open("../p1/modifiers.json"))
FIT = json.load(open("fitparts.json"))
W0 = 62.0
AX = {"top": 669.0, "mid": 342.0, "base": 31.0}
OVERHANG = 140.0
VK = {"a": "a", "e": "e", "ɛ": "eopen", "i": "i", "o": "o", "ɔ": "oopen", "u": "u"}
VOW = list(VK)

def gname(on, v): return VK[v] if on == "" else f"{on}{VK[v]}.liga"

# ------------------------------------------------------------------ geometry helpers
def seglen(P): return float(np.linalg.norm(np.diff(P, axis=0), axis=1).sum()) if len(P) > 1 else 0.0

def turning(Q):
    t = 0.0
    for i in range(1, len(Q) - 1):
        u = Q[i] - Q[i - 1]; v = Q[i + 1] - Q[i]
        if np.linalg.norm(u) > 1e-6 and np.linalg.norm(v) > 1e-6:
            t += math.atan2(u[0] * v[1] - u[1] * v[0], u @ v)
    return abs(math.degrees(t))

def refresh_ends(g):
    use = {}
    for si, s in enumerate(g["strokes"]):
        for i in set(s["idx"]): use.setdefault(i, set()).add(si)
    for si, s in enumerate(g["strokes"]):
        if s["closed"]: continue
        for e, j in ((0, 0), (1, -1)):
            s["ends"][e] = "node" if len(use.get(s["idx"][j], ())) > 1 else "free"

def compact(g):
    used = sorted({i for s in g["strokes"] for i in s["idx"]})
    m = {o: n for n, o in enumerate(used)}
    g["particles"] = [g["particles"][o] for o in used]
    for s in g["strokes"]: s["idx"] = [m[i] for i in s["idx"]]

# ------------------------------------------------------------------ element tagging
def _runs(Q):
    """split a centreline into straight and curved runs (sign changes split curves)"""
    n = len(Q)
    if n < 4: return [(0, n - 1)]
    d = np.diff(Q, axis=0); ang = np.unwrap(np.arctan2(d[:, 1], d[:, 0])); step = np.linalg.norm(d, axis=1)
    k = np.zeros(n)
    for i in range(1, n - 1):
        k[i] = (ang[i] - ang[i - 1]) / max((step[i] + step[i - 1]) / 2, 1e-6)
    from scipy.ndimage import uniform_filter1d
    ks = uniform_filter1d(k, 3)
    lab = np.where(np.abs(ks) < 0.0035, 0, np.sign(ks)).astype(int)
    runs = []; a = 0
    for i in range(1, n):
        if lab[i] != lab[a]: runs.append([a, i - 1]); a = i
    runs.append([a, n - 1])
    changed = True
    while changed and len(runs) > 1:
        changed = False
        for j, r in enumerate(runs):
            if step[r[0]:r[1]].sum() < 45:
                nb = j - 1 if j > 0 else j + 1
                runs[nb] = [min(r[0], runs[nb][0]), max(r[1], runs[nb][1])]; runs.pop(j); changed = True; break
    out = []
    for a, b in runs:
        if out: a = out[-1][1]
        out.append((a, max(b, a + 1)))
    return out

def tag_segments(g):
    P = np.array(g["particles"]) if g["particles"] else np.zeros((0, 2))
    shared = {}
    for si, s in enumerate(g["strokes"]):
        for i in set(s["idx"]): shared.setdefault(i, set()).add(si)
    for si, s in enumerate(g["strokes"]):
        idx = s["idx"]; Q = P[idx]
        if s["closed"]:
            attached = any(len(shared[i]) > 1 for i in idx)
            s["segs"] = [[0, len(idx) - 1, "LOOP-drooping" if attached else "LOOP-floating"]]; continue
        if len(idx) > 3 and np.linalg.norm(Q[0] - Q[-1]) < 25 and seglen(Q) < 900:
            s["segs"] = [[0, len(idx) - 1, "LOOP-drooping"]]; continue
        cuts = [0] + [k for k in range(1, len(idx) - 1) if s["corner"][k]] + [len(idx) - 1]
        segs = []
        for ca, cb in zip(cuts, cuts[1:]):
            for ra, rb in _runs(Q[ca:cb + 1]):
                a, b = ca + ra, ca + rb
                R = Q[a:b + 1]; T = turning(R); L = seglen(R)
                free = (a == 0 and s["ends"][0] == "free") or (b == len(idx) - 1 and s["ends"][1] == "free")
                if T < 25:
                    d = R[-1] - R[0]; o = math.degrees(math.atan2(d[1], d[0])) % 180
                    if 65 < o < 115: el = "EAR" if (L < 170 and R[:, 1].max() > 640 and free) else "STEM"
                    elif o < 25 or o > 155: el = "BAR"
                    else: el = "DIAG"
                elif T >= 330: el = "SPIRAL"
                elif T >= 160 and free and L < 650: el = "CURL"
                else: el = "ARC"
                if segs and segs[-1][2] == el and segs[-1][1] == a: segs[-1][1] = b
                else: segs.append([a, b, el])
        # drooping loop inside an open stroke: the path comes back to itself within a short length
        cum = np.concatenate([[0], np.cumsum(np.linalg.norm(np.diff(Q, axis=0), axis=1))])
        loop = None
        for i in range(len(Q)):
            for j in range(i + 8, len(Q)):
                if cum[j] - cum[i] > 650: break
                if np.linalg.norm(Q[j] - Q[i]) < 26 and cum[j] - cum[i] > 150:
                    loop = (i, j); break
            if loop: break
        if loop:
            i, j = loop; new = []
            for a, b, el in segs:
                if b <= i or a >= j: new.append([a, b, el]); continue
                if a < i: new.append([a, i, el])
                if b > j: new.append([j, b, el])
            new.append([i, j, "LOOP-drooping"]); new.sort()
            segs = new
        s["segs"] = segs

# ------------------------------------------------------------------ cleaning
def clean(g):
    g = copy.deepcopy(g)
    P = np.array(g["particles"]) if g["particles"] else np.zeros((0, 2))
    keep = []
    for s in g["strokes"]:
        if s.get("stub"): continue                                 # no stubs
        Q = P[s["idx"]]; L = seglen(Q)
        if not s["closed"] and L < 70:
            d = Q[-1] - Q[0]; o = math.degrees(math.atan2(d[1], d[0])) % 180
            ear = 65 < o < 115 and Q[:, 1].max() > 640
            if not ear and "free" in s["ends"]: continue          # spur
        keep.append(s)
    g["strokes"] = keep
    refresh_ends(g)
    # snap straight runs: bars to guide axes, stems vertical
    P = np.array(g["particles"]) if g["particles"] else np.zeros((0, 2))
    for s in g["strokes"]:
        idx = s["idx"]
        cuts = [0] + [k for k in range(1, len(idx) - 1) if s["corner"][k]] + [len(idx) - 1]
        for a, b in zip(cuts, cuts[1:]):
            ids = idx[a:b + 1]; R = P[ids]; L = seglen(R)
            if L < 60 or turning(R) > 12: continue
            d = R[-1] - R[0]
            if abs(d[1]) < 0.12 * L:
                y = R[:, 1].mean()
                for ax in AX.values():
                    if abs(y - ax) < 35: P[ids, 1] = ax; break
                else:
                    if np.abs(R[:, 1] - y).max() < 8: P[ids, 1] = y
            elif abs(d[0]) < 0.12 * L and np.abs(R[:, 0] - R[:, 0].mean()).max() < 10:
                P[ids, 0] = R[:, 0].mean()
    g["particles"] = P.tolist()
    compact(g)
    return g

# ------------------------------------------------------------------ composition
def part(g, role, s=1.0, dx=0.0, dy=0.0):
    g = copy.deepcopy(g)
    g["particles"] = [[x * s + dx, y * s + dy] for x, y in g["particles"]]
    g["dots"] = [[x * s + dx, y * s + dy, z] for x, y, z in g.get("dots", [])]
    for st in g["strokes"]: st["role"] = role
    return g

def merge(parts, snap=12.0):
    out = {"particles": [], "strokes": [], "dots": []}
    for k, p in enumerate(parts):
        base = len(out["particles"])
        P_prev = np.array(out["particles"]) if out["particles"] else np.zeros((0, 2))
        out["particles"] += p["particles"]
        newstrokes = []
        for s in p["strokes"]:
            s = copy.deepcopy(s); s["idx"] = [i + base for i in s["idx"]]; newstrokes.append(s)
        # connect free ends of this part to earlier parts
        if k > 0 and len(P_prev):
            for s in newstrokes:
                if s["closed"]: continue
                for e, j in ((0, 0), (1, -1)):
                    if s["ends"][e] != "free": continue
                    q = np.array(out["particles"][s["idx"][j]])
                    d = np.linalg.norm(P_prev - q, axis=1); m = int(np.argmin(d))
                    if d[m] <= snap:
                        s["idx"][j] = m; s["ends"][e] = "node"
        out["strokes"] += newstrokes
        out["dots"] += p.get("dots", [])
    refresh_ends(out)
    compact(out)
    return out

def ink_box(g, w=W0):
    P = np.array(g["particles"])
    return P[:, 0].min() - w / 2, P[:, 1].min() - w / 2, P[:, 0].max() + w / 2, P[:, 1].max() + w / 2

def bar_part(g, level):
    """modifier bar on a guide axis, attached to the radical's right side, overhanging by OVERHANG"""
    y = AX[level]
    P = np.array(g["particles"]); x0i, _, x1i, _ = ink_box(g)
    near = np.where(np.abs(P[:, 1] - y) < 45)[0]
    attached = True
    if len(near):
        i = near[np.argmax(P[near, 0])]; xs = P[i, 0]
        if xs < x1i - 260: attached = False
    else:
        attached = False
    if not attached:
        # snapped guide misses the radical: fall back to the radical's own right arm nearest that level
        right = np.where(P[:, 0] > x1i - W0 / 2 - 90)[0]
        i = right[np.argmin(np.abs(P[right, 1] - y))]
        y = float(P[i, 1]); xs = P[i, 0]
    xe = x1i + OVERHANG
    n = max(2, int(math.ceil((xe - xs) / 14)))
    pts = [[xs + (xe - xs) * k / n, y] for k in range(n + 1)]
    st = {"idx": list(range(len(pts))), "corner": [False] * len(pts), "closed": False, "ends": ["free", "free"], "role": "modifier"}
    return {"particles": pts, "strokes": [st], "dots": []}, attached

def link_bar(left, right_g, level="mid"):
    """short bar on a guide joining a prefix to the vowel on its right (my row)"""
    y = AX[level]
    PL = np.array(left["particles"]); PR = np.array(right_g["particles"])
    nl = np.where(np.abs(PL[:, 1] - y) < 60)[0]; nr = np.where(np.abs(PR[:, 1] - y) < 60)[0]
    xs = PL[nl, 0].max() if len(nl) else PL[:, 0].max()
    xe = PR[nr, 0].min() if len(nr) else PR[:, 0].min()
    if xe - xs < 40: xe = xs + 80
    n = max(2, int(math.ceil((xe - xs) / 14)))
    pts = [[xs + (xe - xs) * k / n, y] for k in range(n + 1)]
    st = {"idx": list(range(len(pts))), "corner": [False] * len(pts), "closed": False, "ends": ["free", "free"], "role": "modifier"}
    return {"particles": pts, "strokes": [st], "dots": []}

def level_for(base, der, v):
    r = next((x for x in MOD if x["base"] == (base or "∅") and x["der"] == der and x["v"] == v), None)
    if r is None: return None
    big = [c for c in r["mods"] if c["area"] > 4000] or r["mods"]
    if not big: return None
    c = max(big, key=lambda c: c["area"]); yc = (c["box"][1] + c["box"][3]) / 2
    return min(AX, key=lambda k: abs(AX[k] - yc))

def bracket_part(src_der, src_base, target):
    """take the bracket strokes from a source glyph and place them beside target's ink"""
    D = SK[src_der]; B = SK[src_base]
    Pd = np.array(D["particles"]); bx = np.array(B["particles"])[:, 0].max()
    strokes = [s for s in D["strokes"] if Pd[s["idx"], 0].min() > bx + 10]
    sub = {"particles": D["particles"], "strokes": copy.deepcopy(strokes), "dots": []}
    compact(sub)
    P = np.array(sub["particles"]); off = P[:, 0].min() - (bx + W0 / 2)      # gap from radical ink edge
    _, _, x1i, _ = ink_box(target)
    P[:, 0] += (x1i + off) - P[:, 0].min()
    sub["particles"] = P.tolist()
    for s in sub["strokes"]: s["role"] = "modifier"
    refresh_ends(sub)
    return sub

# ------------------------------------------------------------------ build all
def main():
    C = {}            # cleaned traced glyphs
    for n, g in SK.items():
        if not g["strokes"] and not g["dots"]: C[n] = copy.deepcopy(g); continue
        C[n] = clean(g)
    out = {}
    notes = {}
    def put(n, g, comp, src):
        g["adv"] = SK[n]["adv"]; g["lsb"] = SK[n]["lsb"]; g["w"] = W0; g["comp"] = comp
        tag_segments(g); out[n] = g; notes[n] = comp
    # radicals & everything traced first
    for n, g in C.items():
        g = copy.deepcopy(g)
        for s in g["strokes"]: s["role"] = "radical"
        put(n, g, "traced", n)
    BARS = {"ky": "t", "tw": "t", "gy": "d", "dw": "d", "hy": "s", "z": "s", "v": "f", "hw": "f", "l": "r", "g": "k", "m": "n", "b": "p", "h": ""}
    for der, base in BARS.items():
        for v in VOW:
            n, bn = gname(der, v), gname(base, v)
            lev = level_for(base, der, v) or "top"
            R = part(C[bn], "radical")
            bp, att = bar_part(R, lev)
            g = merge([R, bp])
            put(n, g, f"{base or 'vowel'} + {lev} bar" + ("" if att else " (snap missed: arm level)"), bn)
    for v in VOW:   # j is gy
        out[gname("j", v)] = copy.deepcopy(out[gname("gy", v)]); out[gname("j", v)]["comp"] = out[gname("gy", v)]["comp"] + " (= gy)"
    # brackets
    for v in VOW:
        R = part(C[gname("p", v)], "radical")
        put(gname("kp", v), merge([R, bracket_part("pa.liga" if False else gname("kp", "a"), gname("p", "a"), R)]), "p + bracket )", None)
        Bg = out[gname("b", v)]
        Bc = {"particles": copy.deepcopy(Bg["particles"]), "strokes": copy.deepcopy(Bg["strokes"]), "dots": Bg.get("dots", [])}
        br = bracket_part(gname("gb", "a"), gname("p", "a"), R)        # placed beside the p radical, like the source
        bxmin = np.array(br["particles"])[:, 0].min()
        PB = np.array(Bc["particles"])
        for st in Bc["strokes"]:
            if st.get("role") == "modifier":
                for i in st["idx"]:
                    PB[i, 0] = min(PB[i, 0], bxmin - W0 - 14)
        Bc["particles"] = PB.tolist()
        put(gname("gb", v), merge([Bc, br]), "b + bracket }", None)
    # glides
    yfit, wfit = FIT["glide_y"], FIT["glide_w"]
    for v in VOW:
        Vg = C[VK[v]]
        mi = part(C["i"], "glide", 0.52, 26, 336)
        put(gname("y", v), merge([part(Vg, "vowel", 1, yfit[v]["vowel"]["dx"], 0), mi]), "mini i (0.52) + vowel", None)
        mo = part(C["oopen"], "glide", 0.34, 32, 462)
        put(gname("w", v), merge([part(Vg, "vowel", 1, wfit[v]["vowel"]["dx"], 0), mo]), "mini ɔ (0.34) + vowel", None)
    # ny = ni = ni sign + medium vowel ; my = ny + mid bar
    nyf = FIT["ny"]
    for v in VOW:
        s = 0.62 if v == "o" else 0.82
        Vg = C[VK[v]]
        vy = np.array(Vg["particles"])[:, 1].min() - W0 / 2
        g = merge([part(C["ni.liga"], "prefix"), part(Vg, "vowel", s, nyf[v]["vowel"]["dx"], -vy * s)])
        put(gname("ny", v), g, f"ni + vowel ({s})", None)
        out[gname("ni", v)] = copy.deepcopy(out[gname("ny", v)]); out[gname("ni", v)]["comp"] += " (= ny)"
        pre = part(C["ni.liga"], "prefix"); vv = part(Vg, "vowel", s, nyf[v]["vowel"]["dx"], -vy * s)
        put(gname("my", v), merge([pre, vv, link_bar(pre, vv)]), "ny + mid link bar", None)
    for a, b in (("koopena.liga", "kwa.liga"), ("koopene.liga", "kwe.liga")):
        out[a] = copy.deepcopy(out[b]); out[a]["comp"] = f"copy of {b}"
    json.dump(out, open("skeleton2.json", "w"))
    import collections
    print("glyphs", len(out), collections.Counter(v["comp"].split(" (")[0] if v["comp"] != "traced" else "traced" for v in out.values()).most_common(30))
    print("floating bars:", [n for n, g in out.items() if "floats" in g["comp"]])

if __name__ == "__main__":
    main()
