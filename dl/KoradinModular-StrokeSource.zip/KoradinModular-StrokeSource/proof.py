"""Compare redrawn strokes against the original outlines: IoU per glyph + overlay sheet."""
import sys, json, math
import numpy as np
from fontTools.ttLib import TTFont
from fontTools.pens.freetypePen import FreeTypePen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.ttGlyphPen import TTGlyphPen
sys.path.insert(0, ".")
from stroke import glyph_contours

def build_glyph(contours):
    pen = TTGlyphPen(None)
    for c in contours:
        if len(c) < 2: continue
        k = next((i for i, p in enumerate(c) if p[2]), None)
        if k is None:
            pen.qCurveTo(*[(round(p[0]), round(p[1])) for p in c], None); pen.closePath(); continue
        c = c[k:] + c[:k]
        pen.moveTo((round(c[0][0]), round(c[0][1]))); buf = []
        for p in c[1:] + [c[0]]:
            pt = (round(p[0]), round(p[1]))
            if p[2]:
                if buf: pen.qCurveTo(*buf, pt); buf = []
                else: pen.lineTo(pt)
            else: buf.append(pt)
        pen.closePath()
    return pen.glyph()

def svgd(contours):
    parts = []
    for c in contours:
        k = next((i for i, p in enumerate(c) if p[2]), 0)
        c = c[k:] + c[:k]
        if not c[0][2]:
            m = ((c[0][0] + c[-1][0]) / 2, (c[0][1] + c[-1][1]) / 2)
        else: m = (c[0][0], c[0][1])
        d = f"M{m[0]:.1f},{m[1]:.1f}"
        pts = c[1:] + [c[0]] if c[0][2] else c + [c[0]]
        prev_off = None
        for p in pts:
            if p[2]:
                d += f"Q{prev_off[0]:.1f},{prev_off[1]:.1f} {p[0]:.1f},{p[1]:.1f}" if prev_off else f"L{p[0]:.1f},{p[1]:.1f}"
                prev_off = None
            else:
                if prev_off:
                    mx, my = (prev_off[0] + p[0]) / 2, (prev_off[1] + p[1]) / 2
                    d += f"Q{prev_off[0]:.1f},{prev_off[1]:.1f} {mx:.1f},{my:.1f}"
                prev_off = (p[0], p[1])
        if prev_off: d += f"Q{prev_off[0]:.1f},{prev_off[1]:.1f} {m[0]:.1f},{m[1]:.1f}"
        parts.append(d + "Z")
    return "".join(parts)

def raster_contours(contours, W=1400, H=1200, ox=200, oy=300):
    pen = FreeTypePen(None)
    build_glyph(contours).draw(pen, None)
    return pen.array(width=W, height=H, transform=(1, 0, 0, 1, ox, oy)) > 0.5

def main():
    src, skf, out = sys.argv[1], sys.argv[2], sys.argv[3]
    f = TTFont(src); gs = f.getGlyphSet()
    sk = json.load(open(skf))
    rows = []; scores = {}
    for name, g in sk.items():
        if not g["strokes"] and not g["dots"]: continue
        pos = np.array(g["particles"]) if g["particles"] else np.zeros((0, 2))
        w = g["w"] if g["w"] > 0 else 62
        cont = glyph_contours(g, pos, w, {"cap": "butt", "node_cap": "round"})
        pen = FreeTypePen(gs); gs[name].draw(pen)
        A = pen.array(width=1400, height=1200, transform=(1, 0, 0, 1, 200, 300)) > 0.5
        B = raster_contours(cont)
        iou = (A & B).sum() / max(1, (A | B).sum())
        scores[name] = round(float(iou), 3)
        sp = SVGPathPen(gs); gs[name].draw(sp)
        skel = ""
        for s in g["strokes"]:
            pts = " ".join(f"{pos[i][0]:.0f},{pos[i][1]:.0f}" for i in s["idx"])
            skel += f'<polyline points="{pts}" fill="none" stroke="#e5484d" stroke-width="5"/>'
            for j, i in enumerate(s["idx"]):
                if s["corner"][j]: skel += f'<circle cx="{pos[i][0]:.0f}" cy="{pos[i][1]:.0f}" r="9" fill="#0090ff"/>'
        rows.append((iou, name, f'<div class="c"><svg viewBox="-60 -150 1300 1000"><g transform="translate(0,700) scale(1,-1)"><path d="{sp.getCommands()}" fill="#cfcfcf"/><path d="{svgd(cont)}" fill="rgba(0,0,0,.55)"/>{skel}</g></svg><b>{name}</b> {iou:.2f}</div>'))
    rows.sort()
    html = "<html><head><meta charset=utf-8><style>body{font:12px sans-serif;margin:10px}.g{display:grid;grid-template-columns:repeat(8,1fr);gap:4px}.c{border:1px solid #ddd;padding:2px}svg{width:100%;display:block}</style></head><body><div class=g>" + "".join(r[2] for r in rows) + "</div></body></html>"
    open(out, "w").write(html)
    v = np.array(list(scores.values()))
    print("glyphs", len(v), "mean IoU", v.mean().round(3), "min", v.min(), "below .85:", sum(v < .85))
    print(sorted(scores.items(), key=lambda x: x[1])[:25])

if __name__ == "__main__":
    main()
