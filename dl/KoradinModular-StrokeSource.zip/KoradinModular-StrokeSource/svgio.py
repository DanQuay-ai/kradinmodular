"""Editable stroke sources.

export: python3 -I svgio.py export skeleton.json <dir>
  One SVG per glyph. Each stroke is a <path> centerline (stroke-width 62, the master width),
  each dot a <circle>. Font units, y up is flipped into SVG space (baseline at y=700).
import: python3 -I svgio.py import <dir> skeleton.json
  Reads the SVGs back (any path type: lines, curves, arcs), resamples them, rebuilds
  junctions (ends within 3 units of another stroke) and corners, writes skeleton.json.
Edit in Illustrator, Figma or Inkscape: keep paths unfilled with a stroke, one path per stroke.
"""
import sys, os, json, math, re
import numpy as np

BASE = 700  # svg y = BASE - font y
SPACING = 14.0


def export(skf, d):
    sk = json.load(open(skf)); os.makedirs(d, exist_ok=True)
    for name, g in sk.items():
        P = g["particles"]
        if not g["strokes"] and not g["dots"]: continue
        parts = []
        for s in g["strokes"]:
            pts = [P[i] for i in s["idx"]]
            dd = "M" + " L".join(f"{p[0]:.1f},{BASE - p[1]:.1f}" for p in pts) + (" Z" if s["closed"] else "")
            parts.append(f'  <path d="{dd}" fill="none" stroke="#000" stroke-width="62" stroke-linejoin="round"/>')
        for x, y, size in g["dots"]:
            parts.append(f'  <circle cx="{x:.1f}" cy="{BASE - y:.1f}" r="31" fill="#000"/>')
        adv = g["adv"]
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="-100 -100 {adv + 200} 1000" data-glyph="{name}" data-advance="{adv}">\n'
               f'  <line x1="-100" x2="{adv + 100}" y1="{BASE}" y2="{BASE}" stroke="#4a90e2" stroke-width="2" data-guide="baseline"/>\n'
               f'  <line x1="-100" x2="{adv + 100}" y1="0" y2="0" stroke="#4a90e2" stroke-width="2" data-guide="top"/>\n'
               + "\n".join(parts) + "\n</svg>\n")
        open(os.path.join(d, safe(name) + ".svg"), "w").write(svg)
    print("exported", len(os.listdir(d)), "glyph SVGs to", d)


def safe(n): return n.replace(".", "_")


def resample(pts):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from skel import resample as rs
    return rs(np.array(pts))


def import_(d, skf):
    from svgpathtools import parse_path
    sk = json.load(open(skf))
    byfile = {safe(n) + ".svg": n for n in sk}
    changed = 0
    for fn in sorted(os.listdir(d)):
        if fn not in byfile: continue
        name = byfile[fn]
        txt = open(os.path.join(d, fn)).read()
        strokes_raw, dots = [], []
        for m in re.finditer(r'<path[^>]*\sd="([^"]+)"', txt):
            p = parse_path(m.group(1))
            if p.length() < 1: continue
            n = max(8, int(p.length() / 2))
            pts = [p.point(t) for t in np.linspace(0, 1, n)]
            closed = p.isclosed()
            pts = [(z.real, BASE - z.imag) for z in pts]
            strokes_raw.append((pts, closed))
        for m in re.finditer(r'<circle[^>]*>', txt):
            cx = float(re.search(r'cx="([-\d.]+)"', m.group(0)).group(1)); cy = float(re.search(r'cy="([-\d.]+)"', m.group(0)).group(1))
            dots.append([cx, BASE - cy, 62.0])
        particles, strokes = [], []
        ends_xy = []  # (stroke idx, end, xy)
        for pts, closed in strokes_raw:
            res, cf = resample(pts if not closed else pts[:-1] + [pts[0]])
            idx = []
            for k, q in enumerate(res):
                idx.append(len(particles)); particles.append([float(q[0]), float(q[1])])
            if closed and len(idx) > 2:
                particles.pop(); idx = idx[:-1]; cf = cf[:-1]
            strokes.append({"idx": idx, "corner": list(map(bool, cf)), "closed": bool(closed), "ends": ["free", "free"]})
        # junctions: a stroke end within 3 units of another stroke's points becomes a shared node
        P = np.array(particles) if particles else np.zeros((0, 2))
        for si, s in enumerate(strokes):
            if s["closed"]: continue
            for e, j in ((0, 0), (1, -1)):
                pid = s["idx"][j]
                others = [i for k, t in enumerate(strokes) if k != si for i in t["idx"]]
                if not others: continue
                dist = np.linalg.norm(P[others] - P[pid], axis=1)
                k = int(np.argmin(dist))
                if dist[k] <= 3.0:
                    s["idx"][j] = others[k]; s["ends"][e] = "node"
        g = sk[name]
        g.update(particles=particles, strokes=strokes, dots=dots)
        changed += 1
    json.dump(sk, open(skf, "w"))
    print("imported", changed, "glyphs into", skf)


if __name__ == "__main__":
    if sys.argv[1] == "export": export(sys.argv[2], sys.argv[3])
    else: import_(sys.argv[2], sys.argv[3])
