"""Repair pass: find ink the strokes miss (short bumps erased by thinning) and add stub strokes."""
import sys, json, math
import numpy as np
from scipy import ndimage
from fontTools.ttLib import TTFont
from fontTools.pens.freetypePen import FreeTypePen
sys.path.insert(0, ".")
from stroke import glyph_contours
from proof import raster_contours

W, H, OX, OY = 1400, 1200, 200, 300

def to_font(r, c): return np.array([c + 0.5 - OX, (H - r - 0.5) - OY])
def to_pix(p): return int(round(H - OY - p[1] - 0.5)), int(round(p[0] - 0.5 + OX))

def main():
    src, skf = sys.argv[1], sys.argv[2]
    f = TTFont(src); gs = f.getGlyphSet()
    sk = json.load(open(skf))
    added = 0
    for name, g in sk.items():
        if not g["strokes"]: continue
        w = g["w"] or 62
        pen = FreeTypePen(gs); gs[name].draw(pen)
        A = pen.array(width=W, height=H, transform=(1, 0, 0, 1, OX, OY)) > 0.5
        pos = np.array(g["particles"])
        B = raster_contours(glyph_contours(g, pos, w, {"cap": "butt", "node_cap": "round"}))
        miss = A & ~ndimage.binary_dilation(B, iterations=3)
        miss = ndimage.binary_opening(miss, iterations=3)
        lab, n = ndimage.label(miss)
        for ci in range(1, n + 1):
            comp = lab == ci
            area = comp.sum()
            if area < 0.3 * w * w: continue
            rr, cc = np.nonzero(comp)
            cen = to_font(rr.mean(), cc.mean())
            dmin = np.linalg.norm(pos - cen, axis=1)
            pi = int(np.argmin(dmin))
            p = pos[pi]
            d = cen - p
            if np.linalg.norm(d) < 1: continue
            d = d / np.linalg.norm(d)
            # march through the original ink to the true end
            q = p.copy(); last_in = p.copy()
            for _ in range(800):
                q = q + d * 0.5
                r, c = to_pix(q)
                if not (0 <= r < H and 0 <= c < W): break
                if A[r, c]: last_in = q.copy()
                elif np.linalg.norm(q - p) > w * 0.6: break
            L = float(np.linalg.norm(last_in - p))
            if L < w * 0.55: continue
            npts = max(2, int(math.ceil(L / 14)))
            idx = [pi]
            for k in range(1, npts + 1):
                t = k / npts
                g["particles"].append((p + (last_in - p) * t).tolist())
                idx.append(len(g["particles"]) - 1)
            g["strokes"].append({"idx": idx, "corner": [False] * len(idx), "closed": False, "ends": ["node", "free"], "stub": True})
            pos = np.array(g["particles"])
            added += 1
    json.dump(sk, open(skf, "w"))
    print("stubs added", added)

if __name__ == "__main__":
    main()
