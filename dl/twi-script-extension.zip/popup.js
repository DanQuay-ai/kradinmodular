const api = typeof browser !== "undefined" ? browser : chrome;
const STYLES = ["Regular", "Rounded", "Serif", "Stencil"];
const DEFAULTS = { enabled: true, script: "kradin", mode: "auto", style: "Regular", weight: 400 };
const $ = (id) => document.getElementById(id);
let cfg = { ...DEFAULTS };

// one font-face per style
const css = STYLES.map((s) => `@font-face{font-family:"KR-${s}";src:url(fonts/KoradinModular-${s}-VF.woff2) format("woff2");font-display:block}`).join("");
document.head.insertAdjacentHTML("beforeend", `<style>${css}</style>`);

// photo header: optional image + credit
const photo = $("photo");
photo.onload = () => $("hero").classList.remove("nophoto");
photo.src = "img/hero.jpg";
fetch("img/credits.json").then((r) => r.json()).then((c) => { if (c && c.hero) { $("credit").textContent = c.hero; $("credit").hidden = false; } }).catch(() => {});

// style chips
const wrap = $("styles");
STYLES.forEach((s) => {
  const b = document.createElement("button");
  b.setAttribute("role", "radio");
  b.dataset.v = s;
  b.innerHTML = `<span class="g" style="font-family:'KR-${s}'">kɔ</span><span class="t">${s}</span>`;
  b.onclick = () => save({ style: s });
  wrap.appendChild(b);
});

function save(patch) { cfg = { ...cfg, ...patch }; api.storage.sync.set(cfg); paint(); }

function setSeg(id, value) {
  const seg = $(id), btns = [...seg.querySelectorAll("button")];
  const i = Math.max(0, btns.findIndex((b) => b.dataset.v === value));
  btns.forEach((b, j) => b.setAttribute("aria-checked", j === i));
  seg.querySelector(".thumb").style.transform = `translateX(${i * 100}%)`;
}
for (const [id, key] of [["script", "script"], ["mode", "mode"]])
  $(id).querySelectorAll("button").forEach((b) => (b.onclick = () => save({ [key]: b.dataset.v })));

let lastScript = null;
function paint() {
  $("enabled").checked = cfg.enabled;
  setSeg("script", cfg.script);
  setSeg("mode", cfg.mode);
  $("kropts").hidden = cfg.script !== "kradin";
  wrap.querySelectorAll("button").forEach((b) => b.setAttribute("aria-checked", b.dataset.v === cfg.style));
  const w = $("weight"); w.value = cfg.weight; $("wv").textContent = cfg.weight;
  w.style.setProperty("--p", ((cfg.weight - 100) / 8) + "%");
  $("wLight").style.cssText = `font-family:"KR-${cfg.style}";font-variation-settings:"wght" 100`;
  $("wHeavy").style.cssText = `font-family:"KR-${cfg.style}";font-variation-settings:"wght" 900`;
  hero();
  tryIt();
}

function fontFor(el) {
  if (cfg.script === "adinkra") { el.style.fontFamily = "AD"; el.style.fontVariationSettings = ""; el.style.fontFeatureSettings = ""; }
  else { el.style.fontFamily = `"KR-${cfg.style}"`; el.style.fontVariationSettings = `"wght" ${cfg.weight}`; el.style.fontFeatureSettings = '"liga","calt"'; }
}
function conv(t) { return cfg.script === "adinkra" ? TwiScript.toAdinkra(t) : TwiScript.toKradin(t); }

function hero() {
  const el = $("heroSample");
  const apply = () => { fontFor(el); el.textContent = conv("akwaaba"); el.classList.remove("out"); };
  $("heroSub").textContent = cfg.script === "adinkra" ? "Twi on any page, in Adinkra" : "Twi on any page, in Kɔradin";
  if (lastScript !== null && lastScript !== cfg.script) { el.classList.add("out"); setTimeout(apply, 180); }
  else apply();
  lastScript = cfg.script;
}

function tryIt() {
  const t = $("try").value, o = $("out");
  const d = TwiScript.detect(t);
  $("det").textContent = d.n ? (d.isTwi ? "Twi detected" : "Not Twi") : "";
  fontFor(o);
  o.textContent = conv(t);
}

$("enabled").onchange = (e) => save({ enabled: e.target.checked });
let wt;
$("weight").oninput = (e) => {
  cfg.weight = +e.target.value; $("wv").textContent = cfg.weight;
  e.target.style.setProperty("--p", ((cfg.weight - 100) / 8) + "%");
  fontFor($("out")); fontFor($("heroSample"));
  clearTimeout(wt); wt = setTimeout(() => save({ weight: cfg.weight }), 200);
};
$("try").oninput = tryIt;

api.storage.sync.get(DEFAULTS, (c) => { cfg = { ...DEFAULTS, ...c }; if (!STYLES.includes(cfg.style)) cfg.style = "Regular"; paint(); });
