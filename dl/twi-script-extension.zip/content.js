/* Twi Script content script: find Twi blocks, render them in Kɔradin or Adinkra. */
(() => {
  const api = typeof browser !== "undefined" ? browser : chrome;
  const DEFAULTS = { enabled: true, script: "kradin", mode: "auto", style: "Regular", weight: 400 };
  const SKIP = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEXTAREA", "INPUT", "SELECT", "OPTION", "CODE", "PRE", "KBD", "SAMP", "SVG", "MATH", "CANVAS", "IFRAME"]);
  const BLOCK = new Set(["P", "DIV", "LI", "TD", "TH", "DD", "DT", "H1", "H2", "H3", "H4", "H5", "H6", "BLOCKQUOTE", "ARTICLE", "SECTION", "FIGCAPTION", "CAPTION", "BODY", "MAIN", "ASIDE", "HEADER", "FOOTER", "NAV"]);
  const CLS = "twis-x";
  let cfg = { ...DEFAULTS };
  const STYLES = ["Regular", "Rounded", "Serif", "Stencil"];
  let observer = null, timer = null;

  function injectCSS() {
    let st = document.getElementById("twis-style");
    if (!st) { st = document.createElement("style"); st.id = "twis-style"; (document.head || document.documentElement).appendChild(st); }
    const kr = api.runtime.getURL(`fonts/KoradinModular-${cfg.style}-VF.woff2`);
    const ad = api.runtime.getURL("fonts/AdinkraAlphabet.ttf");
    st.textContent = `
      @font-face{font-family:"TwisKradin";src:url("${kr}") format("woff2");font-display:block}
      @font-face{font-family:"TwisAdinkra";src:url("${ad}") format("truetype");font-display:block}
      .${CLS}{font-feature-settings:"liga" 1,"calt" 1!important;font-variant-ligatures:common-ligatures contextual!important;letter-spacing:normal!important;text-transform:none!important}
      .${CLS}[data-s="kradin"]{font-family:"TwisKradin"!important;font-size:1.15em!important;font-variation-settings:"wght" ${cfg.weight}!important}
      .${CLS}[data-s="adinkra"]{font-family:"TwisAdinkra"!important}
    `;
  }

  function blockOf(node) {
    let el = node.parentElement;
    while (el && !BLOCK.has(el.tagName)) el = el.parentElement;
    return el || document.body;
  }

  function skippable(el) {
    for (let e = el; e && e !== document.body; e = e.parentElement) {
      if (SKIP.has(e.tagName) || e.isContentEditable || e.classList?.contains(CLS) || e.getAttribute?.("aria-hidden") === "true" && e.tagName === "SVG") return true;
    }
    return false;
  }

  function convertText(t) { return cfg.script === "adinkra" ? TwiScript.toAdinkra(t) : TwiScript.toKradin(t); }

  function scan(root) {
    if (!cfg.enabled || !root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (!n.nodeValue || !/\p{L}/u.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        if (!n.parentElement || skippable(n.parentElement)) return NodeFilter.FILTER_REJECT;
        if (/^\s*[#@]\S+\s*$/.test(n.nodeValue) || /https?:\/\/|www\./.test(n.nodeValue)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    const groups = new Map();
    let n;
    while ((n = walker.nextNode())) {
      const b = blockOf(n);
      if (!groups.has(b)) groups.set(b, []);
      groups.get(b).push(n);
    }
    for (const [block, nodes] of groups) {
      if (cfg.mode === "auto") {
        const text = nodes.map((x) => x.nodeValue).join(" ");
        if (!TwiScript.detect(text).isTwi) continue;
      }
      for (const t of nodes) wrap(t);
    }
  }

  function wrap(t) {
    const orig = t.nodeValue;
    const span = document.createElement("span");
    span.className = CLS;
    span.dataset.s = cfg.script;
    span.dataset.latin = orig;
    span.title = orig.trim();
    span.textContent = convertText(orig);
    t.parentNode.replaceChild(span, t);
  }

  function revertAll() {
    document.querySelectorAll("." + CLS).forEach((s) => s.replaceWith(document.createTextNode(s.dataset.latin)));
  }

  function start() {
    injectCSS();
    scan(document.body);
    if (observer) observer.disconnect();
    observer = new MutationObserver((muts) => {
      if (!cfg.enabled) return;
      const roots = new Set();
      for (const m of muts) {
        for (const a of m.addedNodes) {
          if (a.nodeType === 1 && !a.classList.contains(CLS)) roots.add(a);
          else if (a.nodeType === 3 && a.parentElement && !a.parentElement.classList.contains(CLS)) roots.add(blockOf(a));
        }
        if (m.type === "characterData" && m.target.parentElement && !m.target.parentElement.classList.contains(CLS)) roots.add(blockOf(m.target));
      }
      clearTimeout(timer);
      timer = setTimeout(() => { observer.disconnect(); roots.forEach((r) => r.isConnected && scan(r)); observe(); }, 250);
    });
    observe();
  }
  function observe() { observer.observe(document.body, { childList: true, subtree: true, characterData: true }); }

  function stop() { if (observer) observer.disconnect(); revertAll(); }

  api.storage.sync.get(DEFAULTS, (c) => { cfg = { ...DEFAULTS, ...c }; if (!STYLES.includes(cfg.style)) cfg.style = "Regular"; if (cfg.enabled) start(); });
  api.storage.onChanged.addListener(() => {
    api.storage.sync.get(DEFAULTS, (c) => {
      cfg = { ...DEFAULTS, ...c };
      if (!STYLES.includes(cfg.style)) cfg.style = "Regular";
      stop();
      if (cfg.enabled) start();
    });
  });
})();
